
import React from 'react';
import { BriefcaseIcon } from '../constants';

const Header: React.FC = () => {
  return (
    <header className="bg-white/80 backdrop-blur-md sticky top-0 z-50 shadow-sm">
      <div className="container mx-auto px-6 py-4 flex justify-between items-center">
        <div className="flex items-center space-x-2">
           <BriefcaseIcon className="h-8 w-8 text-brand-primary" />
          <span className="text-2xl font-bold text-brand-primary tracking-tight">
            MyWholesaleMarket
          </span>
        </div>
        <nav>
          <a
            href="#register"
            className="bg-brand-accent hover:bg-orange-500 text-white font-bold py-2 px-6 rounded-full transition duration-300 ease-in-out transform hover:scale-105"
          >
            Register for Free
          </a>
        </nav>
      </div>
    </header>
  );
};

export default Header;
