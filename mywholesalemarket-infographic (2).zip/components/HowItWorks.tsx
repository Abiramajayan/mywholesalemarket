
import React from 'react';
import { UserPlusIcon, MagnifyingGlassIcon, ChartBarIcon } from '../constants';

const Step: React.FC<{ icon: React.ReactNode; title: string; description: string; stepNumber: number }> = ({ icon, title, description, stepNumber }) => (
  <div className="relative flex flex-col items-center">
    <div className="flex items-center justify-center w-20 h-20 bg-brand-primary rounded-full text-white mb-4">
      {icon}
    </div>
    <div className="absolute top-0 right-0 -mt-2 -mr-2 flex items-center justify-center w-8 h-8 bg-brand-accent text-white font-bold rounded-full">{stepNumber}</div>
    <h3 className="text-xl font-semibold text-brand-primary mb-2">{title}</h3>
    <p className="text-center text-gray-600">{description}</p>
  </div>
);

const HowItWorks: React.FC = () => {
  return (
    <section className="py-20 bg-brand-light">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-brand-primary">Get Started in Seconds</h2>
          <p className="mt-4 text-lg text-gray-600">Finding the best wholesale deals has never been easier.</p>
        </div>
        <div className="grid md:grid-cols-3 gap-12 items-start">
          <Step 
            icon={<UserPlusIcon className="h-10 w-10" />}
            title="Register for Free"
            description="Create your account in under a minute. It's completely free, forever."
            stepNumber={1}
          />
          <Step 
            icon={<MagnifyingGlassIcon className="h-10 w-10" />}
            title="Search the Database"
            description="Instantly search our vast catalog of SKUs and suppliers."
            stepNumber={2}
          />
          <Step 
            icon={<ChartBarIcon className="h-10 w-10" />}
            title="Fetch Real-Time Data"
            description="Unlock up-to-date wholesale prices and supplier contact information."
            stepNumber={3}
          />
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
