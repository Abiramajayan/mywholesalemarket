
import React from 'react';

const Hero: React.FC = () => {
  return (
    <section className="bg-brand-light relative">
      <div className="container mx-auto px-6 py-24 text-center">
        <h1 className="text-4xl md:text-6xl font-extrabold text-brand-primary leading-tight">
          Stop Guessing. Start Knowing.
        </h1>
        <p className="mt-4 text-lg md:text-xl text-brand-secondary max-w-3xl mx-auto">
          Unlock real-time wholesale prices from over 2,000 suppliers. MyWholesaleMarket is your free, ultimate knowledge base for B2B procurement.
        </p>
        <div className="mt-8">
          <a
            href="#register"
            className="bg-brand-accent hover:bg-orange-500 text-white font-bold py-4 px-10 rounded-full text-lg transition duration-300 ease-in-out transform hover:scale-105 shadow-lg"
          >
            Get Instant Access
          </a>
        </div>
      </div>
    </section>
  );
};

export default Hero;
