
import React from 'react';
import { DatabaseIcon, TagIcon, UsersIcon } from '../constants';

const FeatureCard: React.FC<{ icon: React.ReactNode; title: string; description: string }> = ({ icon, title, description }) => (
    <div className="bg-white p-6 rounded-lg shadow-md text-center transform hover:-translate-y-2 transition-transform duration-300">
        <div className="flex justify-center items-center h-16 w-16 rounded-full bg-brand-light mx-auto mb-4">
            {icon}
        </div>
        <h3 className="text-2xl font-bold text-brand-primary">{title}</h3>
        <p className="mt-2 text-gray-600">{description}</p>
    </div>
);


const Features: React.FC = () => {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-brand-primary">Your Unfair Advantage in Wholesale</h2>
            <p className="mt-4 text-lg text-gray-600">We provide the data and connections you need to thrive.</p>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
            <FeatureCard
                icon={<UsersIcon className="h-8 w-8 text-brand-primary" />}
                title="2,000+ Suppliers"
                description="Access a curated and growing database of verified wholesale suppliers."
            />
            <FeatureCard
                icon={<DatabaseIcon className="h-8 w-8 text-brand-primary" />}
                title="20,000+ SKUs"
                description="From produce to parts, find wholesale pricing across a massive catalog of products."
            />
            <FeatureCard
                icon={<TagIcon className="h-8 w-8 text-brand-accent" />}
                title="100% Free"
                description="No fees, no commissions. Our goal is to empower your business with free knowledge."
            />
        </div>
      </div>
    </section>
  );
};

export default Features;
