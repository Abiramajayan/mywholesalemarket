
import React from 'react';
import { XCircleIcon, CheckCircleIcon } from '../constants';

const ProblemSolution: React.FC = () => {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-brand-primary">The End of Opaque Pricing</h2>
          <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">Typical e-commerce sites and catalogs hide the true wholesale price. We reveal it.</p>
        </div>

        <div className="flex flex-col md:flex-row justify-center items-stretch gap-8">
          {/* The Problem */}
          <div className="w-full md:w-1/3 bg-red-50 border-2 border-red-200 rounded-xl p-8 text-center shadow-lg">
            <XCircleIcon className="h-16 w-16 text-red-500 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-red-800 mb-2">The Old Way</h3>
            <p className="text-gray-600 mb-4">Purchasers rely on outdated lists or inflated e-commerce prices.</p>
            <div className="bg-white p-4 rounded-lg">
              <p className="text-gray-500 text-sm">Chicken (Whole)</p>
              <p className="text-3xl font-bold text-red-600 line-through">12 AED/kg</p>
              <p className="text-sm text-red-500 mt-1">Inflated Price</p>
            </div>
          </div>

          {/* The Solution */}
          <div className="w-full md:w-1/3 bg-green-50 border-2 border-green-200 rounded-xl p-8 text-center shadow-lg transform md:scale-110 z-10">
            <CheckCircleIcon className="h-16 w-16 text-green-500 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-green-800 mb-2">The MyWholesaleMarket Way</h3>
            <p className="text-gray-600 mb-4">Get direct access to current, transparent wholesale market rates.</p>
            <div className="bg-white p-4 rounded-lg">
              <p className="text-gray-500 text-sm">Chicken (Whole)</p>
              <p className="text-3xl font-bold text-green-600">7 AED/kg</p>
              <p className="text-sm text-green-500 mt-1">Real Wholesale Price</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProblemSolution;
