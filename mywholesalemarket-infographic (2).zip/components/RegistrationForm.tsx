
import React, { useState } from 'react';

const RegistrationForm: React.FC = () => {
    const [formData, setFormData] = useState({
        fullName: '',
        companyName: '',
        email: '',
        password: '',
    });
    const [submitted, setSubmitted] = useState(false);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        // Here you would typically handle form submission, e.g., API call
        console.log('Form Submitted:', formData);
        setSubmitted(true);
    };

    if (submitted) {
        return (
            <section id="register" className="py-20 bg-white">
                <div className="container mx-auto px-6 text-center">
                    <div className="max-w-2xl mx-auto bg-green-100 border-l-4 border-green-500 text-green-700 p-6 rounded-lg shadow-lg">
                        <h2 className="text-2xl font-bold mb-2">Thank You for Registering!</h2>
                        <p>Welcome to MyWholesaleMarket! You now have access to our entire database. A confirmation has been sent to your email.</p>
                    </div>
                </div>
            </section>
        )
    }

    return (
        <section id="register" className="py-20 bg-white">
            <div className="container mx-auto px-6">
                <div className="max-w-2xl mx-auto bg-brand-light p-8 rounded-xl shadow-2xl">
                    <h2 className="text-3xl font-bold text-center text-brand-primary mb-2">Join for Free Today</h2>
                    <p className="text-center text-gray-600 mb-8">Unlock the full power of our wholesale database. No credit card required.</p>
                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div>
                            <label htmlFor="fullName" className="block text-sm font-medium text-gray-700">Full Name</label>
                            <input type="text" name="fullName" id="fullName" value={formData.fullName} onChange={handleChange} required className="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-md shadow-sm focus:ring-brand-primary focus:border-brand-primary" />
                        </div>
                        <div>
                            <label htmlFor="companyName" className="block text-sm font-medium text-gray-700">Company Name</label>
                            <input type="text" name="companyName" id="companyName" value={formData.companyName} onChange={handleChange} required className="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-md shadow-sm focus:ring-brand-primary focus:border-brand-primary" />
                        </div>
                        <div>
                            <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email Address</label>
                            <input type="email" name="email" id="email" value={formData.email} onChange={handleChange} required className="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-md shadow-sm focus:ring-brand-primary focus:border-brand-primary" />
                        </div>
                        <div>
                            <label htmlFor="password" className="block text-sm font-medium text-gray-700">Password</label>
                            <input type="password" name="password" id="password" value={formData.password} onChange={handleChange} required className="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-md shadow-sm focus:ring-brand-primary focus:border-brand-primary" />
                        </div>
                        <div>
                            <button type="submit" className="w-full flex justify-center py-3 px-4 border border-transparent rounded-full shadow-lg text-lg font-bold text-white bg-brand-accent hover:bg-orange-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 transition duration-300">
                                Get Instant Access
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    );
};

export default RegistrationForm;
